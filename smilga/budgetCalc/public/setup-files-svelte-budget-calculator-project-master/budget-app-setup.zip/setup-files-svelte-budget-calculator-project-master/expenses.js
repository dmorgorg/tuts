export default [
  {
    id: Math.random() * Date.now(),
    name: "rent",
    amount: 2300
  },
  {
    id: Math.random() * Date.now(),
    name: "car payment",
    amount: 400
  },
  {
    id: Math.random() * Date.now(),
    name: "student loan",
    amount: 400
  },
  {
    id: Math.random() * Date.now(),
    name: "credit card",
    amount: 2000
  }
];
